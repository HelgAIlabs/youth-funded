---
name: Vibrant Growth
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#414844'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#717973'
  outline-variant: '#c1c8c2'
  surface-tint: '#3f6653'
  primary: '#012d1d'
  on-primary: '#ffffff'
  primary-container: '#1b4332'
  on-primary-container: '#86af99'
  inverse-primary: '#a5d0b9'
  secondary: '#13677b'
  on-secondary: '#ffffff'
  secondary-container: '#a1e7ff'
  on-secondary-container: '#18697e'
  tertiary: '#212a00'
  on-tertiary: '#ffffff'
  tertiary-container: '#344100'
  on-tertiary-container: '#9caf5b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c1ecd4'
  primary-fixed-dim: '#a5d0b9'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#274e3d'
  secondary-fixed: '#b2ebff'
  secondary-fixed-dim: '#8bd1e8'
  on-secondary-fixed: '#001f27'
  on-secondary-fixed-variant: '#004e5f'
  tertiary-fixed: '#d8ec91'
  tertiary-fixed-dim: '#bccf78'
  on-tertiary-fixed: '#171e00'
  on-tertiary-fixed-variant: '#3e4c00'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
  growth-lime: '#D9ED92'
  trust-teal: '#005F73'
  financial-forest: '#1B4332'
  education-gold: '#FFB703'
  glass-fill: rgba(255, 255, 255, 0.7)
  glass-stroke: rgba(255, 255, 255, 0.4)
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 64px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.4'
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
  body-lg:
    fontFamily: Source Serif 4
    fontSize: 20px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Source Serif 4
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  stack-xs: 4px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
  stack-xl: 64px
---

## Brand & Style

This design system is engineered for a youth-led financial empowerment movement. It balances the precision of a professional financial institution with the vibrant, optimistic energy of a community-focused grassroots organization. The visual narrative centers on "Financial Inclusion as Growth," utilizing a sophisticated **Glassmorphism** style to represent transparency and clarity.

The style is defined by a "Modern Professionalism" that avoids the stiffness of traditional banking. It uses deep, trustworthy tones layered with high-energy accents to appeal to a younger demographic.

**Key Principles:**
- **Dynamic Transparency:** Extensive use of frosted glass effects to symbolize the "open-door" nature of the organization.
- **Vibrant Trust:** High-contrast combinations of forest greens and teals paired with energetic lime highlights.
- **Editorial Structure:** Bold, block-style typography that commands attention and establishes authority in the financial literacy space.

## Colors

The palette shifts from organic greens to a more "Institutional-Vibrant" hybrid. The **Financial Forest** green provides a grounded, stable foundation, while **Trust Teal** adds a layer of modern professionalism. 

**Growth Lime** and **Education Gold** serve as high-energy accents for call-to-actions, progress indicators, and key data points. 

**Implementation Notes:**
- **Primary Action:** Use `#1B4332` for core interactive elements and primary headers.
- **Accents:** Use `#D9ED92` for highlights to evoke a sense of "fresh starts" and burgeoning growth.
- **Glass Surfaces:** Containers use `glass-fill` with a 24px - 40px backdrop blur. A 1px stroke of `glass-stroke` must be applied to the top and left edges to simulate light hitting a physical edge.

## Typography

The system maintains a high-contrast pairing between a geometric sans-serif and a literary serif.

- **Plus Jakarta Sans:** Used for all "Block Style" headlines. Headlines should use heavy weights (700-800) and negative letter spacing to create a dense, authoritative impact.
- **Source Serif 4:** Used for educational content and body copy. This choice reinforces the "Literacy" and "Education" pillars of the brand, providing a scholarly and trustworthy reading experience.
- **Labels:** Always use Plus Jakarta Sans in bold, uppercase for eyebrows and metadata tags to maintain a structured, editorial feel.

## Layout & Spacing

This design system utilizes a **12-column fluid grid** for desktop, prioritizing generous whitespace to maintain the "Airy" quality of the brand.

- **Grid Logic:** On desktop, use a 64px outer margin to "frame" the content, creating a centered, magazine-like feel.
- **Vertical Rhythm:** Spacing is categorized into "Stacks." Use `stack-lg` (32px) for internal card padding and `stack-xl` (64px) to separate distinct sections of information.
- **Mobile Reflow:** Elements collapse to a single column with 20px margins. Glass containers should retain their translucency to allow background depth to show through during scroll.

## Elevation & Depth

Depth is established through the interaction of light, transparency, and soft shadows, rather than harsh offsets.

- **Surface Layers:** The base layer is a subtle neutral (`#F8F9FA`). Level 1 containers are glass panels with backdrop blurs. 
- **Ambient Shadows:** To distinguish interactive glass elements from static ones, apply a very soft, diffused shadow: `0 20px 40px rgba(27, 67, 50, 0.08)`. The shadow color is tinted with the primary forest green to keep the depth feeling natural.
- **Interactive States:** On hover, elements should increase their `backdrop-filter: blur()` from 24px to 40px and apply a subtle upward translation (-2px) to simulate "lifting" off the surface.

## Shapes

The shape language is consistently **Rounded**, providing a soft counter-balance to the bold, blocky typography.

- **Standard Radius:** 0.5rem (8px) for small components like inputs and thumbnails.
- **Large Radius:** 1rem (16px) for cards and main containers to create a distinct, friendly frame.
- **Pills:** All buttons and categorical chips must use full-rounded "pill" shapes (9999px) to clearly identify them as interactive or status-based elements.

## Components

### Buttons
Primary buttons are solid `financial-forest` (#1B4332) with white text. Secondary buttons use a glass background with a 1px border of `trust-teal` (#005F73). All buttons are pill-shaped.

### Glass Cards
The core container. Must include a 24px backdrop blur and a `stack-lg` internal padding. Cards should have a 1px border at 40% opacity of the neutral color to define their edges against the background.

### Input Fields
Utilize a semi-transparent white background with a 1px border. On focus, the border transitions to `trust-teal` and the background becomes 100% opaque white.

### Progress & Growth Indicators
For tracking SDGs or funding goals, use thick pill-shaped tracks. The background track is a 10% opacity version of `growth-lime`, and the indicator is a solid `growth-lime` (#D9ED92).

### Chips & Tags
Small, high-visibility pills used for labeling content types (e.g., "Financial Literacy"). These use `growth-lime` backgrounds with `financial-forest` text for maximum legibility and "vibrant" energy.